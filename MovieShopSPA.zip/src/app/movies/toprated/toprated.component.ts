import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toprated',
  templateUrl: './toprated.component.html',
  styleUrls: ['./toprated.component.css']
})
export class TopratedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
