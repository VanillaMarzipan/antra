import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; // Vid 4 37:50
import { MovieCard } from 'src/app/shared/models/movieCard';
import { Observable } from 'rxjs'; // RxJS as JS LinQ
import { environment } from 'src/environments/environment'; // Vid 4 53:40, avoid url hardcoding

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  // int x;
  constructor(private http: HttpClient) { }

  // Home component
  // returns models
  getTopGrossingMovies() : Observable<MovieCard[]> {

    // 21:10 Convert Json data to TS models and return
    // need to create models
    // JS Async promises -> observables
    // Angular uses observables extensively in the framework

    // 43:20
    // Angular services return obsv. obj
    // <MovieCard> maps an obsv.obj to an obsv MovieCard
    //return this.http.get<MovieCard[]>('https://localhost:5001/api/Movies/toprevenue');

    // 54:50 Hardcode-free version
    return this.http.get<MovieCard[]>(`${environment.apiUrl}movies/toprevenue`);

    // Alt mapping method
    // return this.http.get('https://localhost:5001/api/Movies/toprevenue').pipe(map(resp => resp as MovieCard[]));

    // Then Homepage calls this method!
  }

}
