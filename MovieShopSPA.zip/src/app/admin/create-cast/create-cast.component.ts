import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-cast',
  templateUrl: './create-cast.component.html',
  styleUrls: ['./create-cast.component.css']
})
export class CreateCastComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
