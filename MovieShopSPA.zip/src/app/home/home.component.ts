import { Component, OnInit } from '@angular/core';
import { MovieService } from '../core/services/movie.service';
import { MovieCard } from '../shared/models/movieCard';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // init a model 
  movieCards!: MovieCard[]; // ! makes it nullable

  constructor(private movieService: MovieService) { }

  // Vid 4 1:00:00 this method calls API
  ngOnInit(): void {
    this.movieService.getTopGrossingMovies()
      .subscribe(m=>{
        this.movieCards = m;
        console.log("Inside Home Component init method");
        //console.log(this.movieCards); // Vid 4  1:58:50
        console.table(this.movieCards); // better formatting
      }) // get notification only when subscribed!
  }

}
