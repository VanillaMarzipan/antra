export interface MovieCard{
    id: number;
    title: string;
    posterUrl: string;
    releaseDate: Date;
}